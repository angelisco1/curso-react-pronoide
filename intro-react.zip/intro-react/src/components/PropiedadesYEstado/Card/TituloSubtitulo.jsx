import React from 'react'

const TituloSubtitulo = (props) => {
  return (
    <div>
      <p>{props.titulo}</p>
      <p>{props.subtitulo}</p>
    </div>
  )
}

export default TituloSubtitulo

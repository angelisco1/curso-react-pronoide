import React from 'react'

const Card2 = ({children}) => {
  return (
    <div>
      {children}
    </div>
  )
}

export default Card2

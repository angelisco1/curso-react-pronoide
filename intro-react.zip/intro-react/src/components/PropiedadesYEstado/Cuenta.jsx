import React from 'react'

const Cuenta = ({cuenta}) => {
  return (
    <div>
      {cuenta}
    </div>
  )
}

export default Cuenta

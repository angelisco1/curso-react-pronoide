import React from 'react';

// No podían tener estado
const CmpFuncional = () => {


  return (
    <p>Soy un componente funcional!!!</p>
  )
}

export default CmpFuncional;